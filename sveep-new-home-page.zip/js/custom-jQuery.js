var jQ = jQuery.noConflict();

jQ(document).ready(function(){

   //This function for sticky header
   jQ(window).scroll(function(){
      if(jQ(this).scrollTop() > 50){
         jQ('.top-head').addClass('Sticky-top-head');
      }else{
         jQ('.top-head').removeClass('Sticky-top-head');
      }
   });


   //This is for Main-menu Function
   jQ('.menu-btn').on('click',function(){
      jQ('.nav-wrap').addClass('side-down');
         jQ('.cloze-btn').delay(1000).fadeIn(800);
   });
   jQ('.cloze-btn').on('click',function(){
      jQ('.nav-wrap').removeClass('side-down');
         jQ(this).hide();
   });
   
   //This Function For width Condition

   jQ(window).width(function(){
      if(jQ(this).width() > 768){
         //This Function For Photo Gallery common Height
         var glyHght = jQ('.ec-officer').height() + 25;
         jQ('.photo-gallery,.ec-officer').css({'height': glyHght});

         var hght = jQ('.map-election').height() + 250;
         jQ('.election-rslts').css({'height': hght});
      }
      
   });
    
});